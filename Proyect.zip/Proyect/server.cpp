#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <map>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <algorithm>
#include <netdb.h>
#include <iostream>
#include <stdio.h> 
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/syscall.h>
#include <pthread.h>
#include <condition_variable>
#include <time.h>
#include <chrono>
#include <unistd.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include "new.pb.h"


using namespace std;
using namespace chat;
using namespace google::protobuf;

#define HOSTNAME "localhost"
#define BUFSIZE 4096    // max number of bytes we can send at once
#define BACKLOG 10          // how many pending connections queue will hold

// Quitar por si no es necesario
#define MAX_CLIENTS 15

int sockfd, portno;
int fd[2];

int clientCount = 0;
int idCount = 1;
struct sockaddr_in serv_addr;
pthread_t threadPool[MAX_CLIENTS];
void * retvals[MAX_CLIENTS];

static void err(const char* s) {
    perror(s);
    exit(EXIT_FAILURE);
}

struct User{
    string username;
    string status;
    //int socket;
    string ip;
};

map<string, User> users;

int main(int argc, char *argv[])
{
    int portno, n;
    struct sockaddr_in serv_addr;
    struct hostent *server;
    bool salir = false;
    char buffer[BUFSIZE];

    GOOGLE_PROTOBUF_VERIFY_VERSION;

    if (argc < 2) {
       fprintf(stderr,"Not enough arguments given\n", argv[0]);
       exit(0);
    }
    
    cout << "Works" << endl;
    
    int res = pipe(fd);
    if (res < 0) {
        cout << "Error al crear el canal de comunicación" << endl;
        exit(1);
    }

    pthread_t tidod, tidm;

    portno = atoi(argv[1]);
    sockfd = socket(AF_INET, SOCK_STREAM, 0);

    if (sockfd < 0) 
        err("Socket error");

    
    cout << "Works2" << endl;
    // server = gethostbyname(argv[2]);

    cout << "Works3" << endl;
    // if (server == NULL) {
    //     fprintf(stderr,"Host name error\n");
    //     exit(0);
    // }

    bzero((char *) &serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;

    bcopy((char *)server -> h_addr, (char *)&serv_addr.sin_addr.s_addr, server->h_length);
    serv_addr.sin_port = htons(portno);
    cout << "Works4" << endl;

    if (connect(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0) 
        err("Connection error");
        
    
    struct User currentClient;
    cout << "Works5" << endl;
    
    
    while (true)
    {
        /* code */
        ClientPetition clip;
        recv(sockfd, buffer, BUFSIZE, 0);
        clip.ParseFromString(buffer);
        int option = clip.option();
        
        //Registrar Cliente
        if (option == 1)
        {
            if (users.count(clip.registration().username()) > 0)
            {
                cout << "Ese usuario ya esta registrado" << endl;
            }
            
            //Guardar
            currentClient.username = clip.registration().username();
            currentClient.ip = clip.registration().ip();
            currentClient.status = "Activo";

            struct User newuser;
            newuser.username = currentClient.username;
            newuser.ip = currentClient.ip;

            users.insert(pair<string,User>(currentClient.username, newuser));

            //Enviar mensaje de confirmacion
            ServerResponse response;
            response.set_option(1);
            response.set_code(200);
            response.set_servermessage("Registrado con éxito");

            string binary;
            response.SerializeToString(&binary);

            char cstr[binary.size() + 1];
            strcpy(cstr, binary.c_str());
            int sent = send(sockfd, cstr, strlen(cstr), 0);
            if (sent == 0)
            {
                fprintf(stderr, "No se pudo notificar \n");
            }
        }


        //Lista de clientes conectados

        else if (option == 2){
            string connectedUsers = "";
            cout << "Lista de usuarios conectados: \n" << endl;
            for (auto i = users.begin(); i != users.end(); ++i)
            {
                //connectedUsers += advance(firstUser, i);
                string itrUsername = i->first;
                // Obtener el usuario del diccionario
                struct User u = i->second;

                cout << "\tUSER: " << itrUsername << "\tSTATUS: " << u.status << "\tIP: " << u.ip << endl;
            }

            // ConnectedUsersResponse * userList(new ConnectedUsersResponse);

            // userList->set_allocated_connectedusers(connectedUsers);

            // ServerResponse sResponse;
            // sResponse.set_option(3);
            // sResponse.set_allocated_connectedusers(userList);

            
        }
        

        //Cambio de estado
        else if (option == 3){


        }

        //Mensajes
        else if (option == 4){
            MessageCommunication* broadMessage(new MessageCommunication);
            broadMessage->set_message(clip.messagecommunication().sender());

            //Chat publico
            if (clip.messagecommunication().recipient() == "everyone")
            {
                cout << "Chat publico" << endl;
                for(auto i = users.begin(); i != users.end(); ++i)
                {
                    if (i->first != currentClient.username)
                    {
                        broadMessage->set_recipient(clip.messagecommunication().recipient());
                        
                        ServerResponse response;
                        response.set_option(1);
                        response.set_allocated_messagecommunication(broadMessage);

                        string binary;
                        response.SerializeToString(&binary);

                        char cstr[binary.size() + 1];
                        strcpy(cstr, binary.c_str());
                        int sent = send(sockfd, cstr, strlen(cstr), 0);
                        if (sent == 0)
                        {
                            fprintf(stderr, "No se envio el mensaje\n");
                        }

                    }
                }

            }
            //Chat privado
            else
            {
                if (users.count(clip.messagecommunication().recipient()) > 0)
                {
                    cout << "Ese usuario no esta conectado" << endl;
                }
                cout << "Chat con" << clip.messagecommunication().recipient() << endl;
                broadMessage->set_recipient(clip.messagecommunication().recipient());
                        
                ServerResponse response;
                response.set_option(1);
                response.set_allocated_messagecommunication(broadMessage);

                string binary;
                response.SerializeToString(&binary);

                char cstr[binary.size() + 1];
                strcpy(cstr, binary.c_str());
                int sent = send(sockfd, cstr, strlen(cstr), 0);
                if (sent == 0)
                {
                    fprintf(stderr, "No se envio el mensaje\n");
                }
            }
            

        }

        // Informacion de usuario especifico
        else if (option == 5){
        
            if (users.count(clip.users().user()) == 0)
            {
                cout << "Ese usuario no esta conecctado" << endl;
            }
            else
            {
                auto u = users.find(clip.users().user());
                cout << "User: " << u->first << "IP: " << u->second.ip << endl;
            }

        }   
    }

}
